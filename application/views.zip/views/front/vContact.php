<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15840.13016524645!2d113.8537743!3d-7.005451099999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd9e7f70d5bb207%3A0x61d22d608be3e032!2sLabatik!5e0!3m2!1sid!2sid!4v1580182890471!5m2!1sid!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>

<br>
<br>
<div class="row">
    <div class="col-md-4">
        <h2 class="light-title">Contact <strong>Details</strong></h2>

        <div class="contact-info">
            <div>
                <i class="icon-phone"></i>
                <p><a href="https://wa.me/<?php echo $no_wa ?>?text=Halo%20labatik">WA</a></p>
                <p><a href="https://wa.me/<?php echo $no_wa ?>?text=Halo%20labatik"><?php echo $no_wa ?></a></p>

            </div>
            <div>
                <i class="icon-instagram"></i>
                <p><a href="https://www.instagram.com/labatik.id/">Labatik.id</a></p>
            </div>
        </div><!-- End .contact-info -->
    </div><!-- End .col-md-4 -->
</div><!-- End .row -->
