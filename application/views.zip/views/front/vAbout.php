
<div class="about-section">
    <div class="container">
        <h2 class="subtitle">WHAT WE ARE<span>ABOUT US</span></h2>
        
        <p>
        <?php echo $about ?>
        </p>
    </div><!-- End .container -->
</div><!-- End .about-section -->

<div class="company-section" style="">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 offset-lg-5">
            <h2 class="subtitle">SPECIALITY<span>WHY CHOOSE US</span></h2>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="info-box">
                            <i class="icon-support"></i>

                            <div class="info-box-content">
                                <h3>ONLINE SUPPORT</h3>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting. industry.</p>
                            </div><!-- End .info-box-content -->
                        </div><!-- End .info-box -->
                    </div><!-- End .col-md-6 -->

                    <div class="col-md-6">
                        <div class="info-box">
                            <i class="icon-shipping"></i>

                            <div class="info-box-content">
                                <h3>FREE SHIPPING & RETURN</h3>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting. industry.</p>
                            </div><!-- End .info-box-content -->
                        </div><!-- End .info-box -->
                    </div><!-- End .ol-md-6 -->

                    <div class="col-md-6">
                        <div class="info-box">
                            <i class="icon-us-dollar"></i>

                            <div class="info-box-content">
                                <h3>MONEY BACK GUARANTEE</h3>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting. industry.</p>
                            </div><!-- End .info-box-content -->
                        </div><!-- End .info-box -->
                    </div><!-- End .col-md-6 -->

                    <div class="col-md-6">
                        <div class="info-box">
                            <i class="icon-support"></i>

                            <div class="info-box-content">
                                <h3>MONEY BACK GUARANTEE</h3>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting. industry.</p>
                            </div><!-- End .info-box-content -->
                        </div><!-- End .info-box -->
                    </div><!-- End .col-md-6 -->
                </div><!-- End .row -->
            </div><!-- End .col-lg-7 -->
        </div><!-- End .row -->
    </div><!-- End .container -->
</div><!-- End .about-section -->